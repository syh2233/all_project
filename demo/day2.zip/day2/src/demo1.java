public class demo1 {
    public static void main(String[] args)
    {
        printHelloWorld();
    }
    public static void printHelloWorld()
    {

    }
}
