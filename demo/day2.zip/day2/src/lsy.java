import java.util.Scanner;
public class lsy {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        exam14();
    }
    public static void exam1(){
        long s = 1;
        int i = 1;
        while (i<=100) {
            s *= i;
            i++;
        }
        System.out.println(s);
    }

    public static void exam2(){
        int i = 0;
        while (i<=4) {
            i++;
            System.out.println("x="+i);
        }

    }
    public static void exam3(){
        long s = 1;
        int i = 1;
        while (i<=5) {
            s += i;
            i++;
        }
        System.out.println(s);

    }
    public static void exam4(){
        long s = 1;
        int i = 99;
        while (i<=200) {
            s += i;
            i++;
        }
        System.out.println(s);

    }
    public static void exam5(){
        int rows = 5;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i * 2 - 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

    }
    public static void exam6(){
        long sum = 0; // 用于存储阶乘和的变量
        long factorial = 1; // 用于计算阶乘的变量

        // 从1到20的循环
        for (int i = 1; i <= 20; i++) {
            factorial *= i; // 计算i的阶乘
            sum += factorial; // 将阶乘加到和中
        }

        System.out.println("The sum of factorials from 1! to 20! is: " + sum);
    }
    public static void exam7(){
        int a,b,c,d;
        int i = 999;
        while (i<=8999){
            i++;
            a = i / 1000;//qian
            b = (i%1000)/100;//bai
            c = (i%100)/10;//shi
            d = i%10;
            if (a==d&&b==c){
                System.out.println(i);
            }
        }
    }
    public static void exam8(){
        double e = 1.0; // 初始化e的值
        double factorial = 1.0; // 用于计算阶乘的变量

        // 从1到10的循环
        for (int i = 1; i <= 10; i++) {
            factorial /= i; // 计算i的阶乘的倒数
            e += factorial; // 将阶乘的倒数加到e中
        }

        System.out.println("The approximation of e is: " + e);
    }
    public static void exam9(){
        double p = 1.0; // 初始化p的值
        double term = 1.0; // 当前项的值
        int denominator = 1; // 分母的值，从1开始

        // 循环直到某项小于10^-4
        while (term >= 0.0001) {
            term = 1.0 / (denominator * 2 - 1); // 计算当前项的值
            p += term; // 将当前项加到p中
            denominator++; // 移动到下一项
        }

        System.out.println("The approximation of p is: " + p);
    }
    public static void exam10(){
        double piOver4 = 0.0; // 初始化π/4的值
        double term = 1.0; // 当前项的值
        int denominator = 1; // 分母的值，从1开始
        int sign = 1; // 符号，1表示正，-1表示负

        // 循环直到某项的绝对值小于10^-6
        while (Math.abs(term) >= 0.000001) {
            term = sign * (1.0 / (denominator * 2 - 1)); // 计算当前项的值
            piOver4 += term; // 将当前项加到π/4中
            denominator++; // 移动到下一项
            sign = -sign; // 改变符号
        }

        // 将π/4转换为π
        double pi = 4 * piOver4;

        System.out.println("The approximation of pi is: " + pi);
    }
    public static void exam11(){
        int n = 10; // 假设n的值为10，您可以根据需要修改这个值
        long sum = 0; // 用于存储序列和的变量
        long innerSum = 0; // 用于计算内层括号和的变量

        // 外层循环控制括号的数量
        for (int i = 1; i <= n; i++) {
            innerSum = 0; // 每次外层循环开始时重置内层和
            // 内层循环计算括号内的和
            for (int j = 1; j <= i; j++) {
                innerSum += j; // 将j加到内层和中
            }
            sum += innerSum; // 将内层和加到总和中
        }

        System.out.println("The sum of the series is: " + sum);
    }
    public static void exam12(){
        double e = 1.0; // 初始化e的值
        double factorial = 1.0; // 用于计算阶乘的变量

        // 从1到10的循环
        for (int i = 1; i <= 10; i++) {
            factorial *= i; // 计算i的阶乘
            e += 1.0 / factorial; // 将阶乘的倒数加到e中
        }

        System.out.println("The approximation of e is: " + e);
    }
    public static void exam13(){
        int i = 100;
        while (i<=100){
            if(i%5==0&&i%7==0) {
                System.out.println(i);
            }
            i++;
        }
    }
    public static void exam14(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of terms n: ");
        int n = scanner.nextInt();
        scanner.close();

        double sum = 0.0; // 用于存储序列和的变量
        double prevFib = 1.0; // 前一个斐波那契数
        double currFib = 1.0; // 当前斐波那契数

        // 计算前n项的和
        for (int i = 1; i <= n; i++) {
            sum += currFib / prevFib; // 将当前项加到和中
            double nextFib = prevFib + currFib; // 计算下一个斐波那契数
            prevFib = currFib; // 更新前一个斐波那契数
            currFib = nextFib; // 更新当前斐波那契数
        }

        System.out.println("The sum of the first " + n + " terms of the Fibonacci fraction sequence is: " + sum);
    }
    public static void exam15(){
        int rows = 5; // 假设行数为5，您可以根据需要修改这个值

        // 外层循环控制行数
        for (int i = 1; i <= rows; i++) {
            // 内层循环控制每行打印的星号数量
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            // 每打印完一行后换行
            System.out.println();}
    }
    public static void exam16(){
        int size = 9; // 九九乘法表的大小

        // 外层循环控制行数
        for (int i = 1; i <= size; i++) {
            // 内层循环控制每行打印的内容
            for (int j = 1; j <= i; j++) {
                System.out.printf("%d*%d=%2d  ", j, i, i * j); // 使用printf来格式化输出
            }
            // 每打印完一行后换行
            System.out.println();
        }
    }
    public static void exam17(){
        for (int x = 0; x <= 20; x++) { // 遍历鸡翁的可能数量
            for (int y = 0; y <= 33; y++) { // 遍历鸡母的可能数量
                int z = 100 - x - y; // 计算鸡雏的数量
                if (z % 3 == 0 && 5 * x + 3 * y + z / 3 == 100) { // 检查方程是否成立
                    System.out.println("鸡翁：" + x + " 只，鸡母：" + y + " 只，鸡雏：" + z + " 只");
                }
            }
        }
    }
}